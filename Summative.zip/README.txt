To run, execute rs_ui.py from command line or IDE.
Pre-processed dataset is included with sample of 1000. Possible to resample from businesses file if at {FILEPATH}.csv in rs_sampler.py.
If sample size is increased (default=200), user data must be removed due to restructure and reindexing of items.
json_to_csv_converter.py included in case you wish to run the dataset. It is from https://github.com/Yelp/dataset-examples. All the other code is my own work. rs_ui.Program.take_input() is modified from code I wrote previously.